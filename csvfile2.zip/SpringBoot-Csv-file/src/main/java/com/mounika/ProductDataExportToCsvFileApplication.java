package com.mounika;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class ProductDataExportToCsvFileApplication implements CommandLineRunner{
	
	@Autowired
	ProductRepo productRepo;
	
	public static void main(String[] args) {
		SpringApplication.run(ProductDataExportToCsvFileApplication.class, args);
	}
	
	   @Override
	    public void run(String... args) throws Exception {
	        List<Product> products = new ArrayList<>();
	 
	        //creating sample employees
	        
	        products.add(new Product("OFM Essentials 3-Paddle Ergonomic Mesh High-Back Chair, Black/Silver", "$249.99", 870521, "ESS-3050","Ergonomic Office Chairs"
	        		, "The Essentials by OFM seating collection is where quality meets value."));
	        products.add(new Product("WorkPro® 1000 Series Ergonomic Mesh/Mesh Mid-Back Task Chair, Black/Black"
	        		, "$319.99"
	        		, 604924
	        		, "WorkPro 1000 Series"
	        		,"Ergonomic Office Chairs"
	        	     , "Create a custom seating option in your workplace with this WorkPro 1000 .Series ergonomic mesh task chain"
	        												));
	        products.add(new Product("WorkPro® Momentum Ergonomic Mesh Active High-Back Chair, Black",
	        		"$429.99",
	        		8517865,
	        		"3D headrest",
	        		"Office Chairs",
	        		"The flexible, agile design of the WorkPro Momentum Mesh Active High-Back Chair is responsive throughout a wide range of movement and positions "

	 ));
	        products.add(new Product("WorkPro® Momentum Mesh Active High-Back Chair, Gray",
	        		"$429.99",
	        		2864384,
	        		"3D headrest",
	        		"Office Chairs",
	        		"The flexible, agile design of the WorkPro Momentum Mesh Active High-Back Chair is responsive throughout a wide range of movement and positions from top to bottom. "




	 ));
	        products.add(new Product("WorkPro® Quantum 9000 Series Ergonomic Mesh/Mesh Mid-Back Chair, Black/Black",
	        		"$549.99",
	        		510830,
	        		"3D headrest",
	        		"Office Chairs",
	        		"Give your office a modern look with this black WorkPro Quantum 9000 Series ergonomic chair.A lumbar support feature helps improve posture, while the mesh back material optimizes airflow to keep you cool. "


    ));
	        products.add(new Product("Serta® Smart Layers™ Siena Bonded Leather Mid-Back Manager's Chair, Brown",
	        		"$249.99",
	        		3972751,
	        		"Serta Smart Layers Siena mid-back manager's chair",
	        		"Office Chairs",
	        		"Add a plush seating solution to your workspace with this Serta Smart Layers Siena mid-back manager's chair. The bonded leather upholstery allows effortless cleaning, while the rolling casters provide maneuverability around your desk. An ergonomic design with lumbar support  "





    ));
	        products.add(new Product("WorkPro® 12000 Series Ergonomic Mesh High-Back Executive Chair, Black/Chrome",
	        		"$629.99",
	        		6356490,
	        		"ergonomic WorkPro 12000 Series high-back executive chair",
	        		"Office Chairs",
	        		"comfortable workstation with this WorkPro 12000 Series Series high-back executive chair. The swivel and rolling casters offer effortless mobility, and the breathable mesh back allows airflow for cooling comfort. This ergonomic WorkPro 12000 Series high-back executive chair features a height-adjustable design for finding the correct sitting position, while the padded armrests provide upper body support. "

));
	        products.add(new Product("Shaquille O'Neal™ Zethus Ergonomic Bonded Leather High-Back Executive Chair, Brown",
	        		"$499.99",
	        		7391635,
	        		"bonded leather upholstery delivers style.",
	        		"Office Chairs",
	        		"Complete your modern workstation with this Shaquille O'Neal Zethus high-back executive chair. Individually wrapped coils and cool reaction memory foam ensure all day comfort, while the bonded leather upholstery delivers style. With a waterfall seat and AIR lumbar system, this ergonomic office chair fully supports your frame. Enjoy maximum flexibility and easy customization with the adjustable height, tilt and armrests on this Shaquille O'Neal Zethus high-back executive chair."


));
	        products.add(new Product("Mind Reader Ergonomic Mesh Mid-Back Rolling Office Chair, Black",
	        		"$119.99",
	        		1802696,
	        		"Built-in lumbar",
	        		"Office Chairs",
	        		"Design a comfortable, stylish office space with the addition of a Mind Reader Ergonomic Mesh Mid-Back Rolling Office Chair. Built-in lumbar helps to support your spine during long periods of sitting, while the mesh back helps you stay cool. The rolling casters allow you to quickly move from your desk to the bookshelf to the file cabinet and back. "





));
	        products.add(new Product("Boss Commercial Grade Ergonomic Mesh High-Back Task Chair With Arms, Black",
	        		"$119.99",
	        		6126549,
	        		"Boss Commercial Grade Ergonomic Mesh High-Back Task Chair",
	        		"Office Chairs",
	        		"Stay comfortable during the workday while seated in the Boss Commercial Grade Ergonomic Mesh High-Back Task Chair With Arms. Integrated lumbar support offers ample support during long periods of sitting. Rolling casters allow you to move around your space with ease."







));
	 
	        	     productRepo.saveAll(products);
	    }

}
