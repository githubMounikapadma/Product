package com.mounika.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mounika.Product;
import com.mounika.ProductRepo;

@Service
public class ProductService {
	
	@Autowired
    ProductRepo productRepository;
 
    public List<Product> findAll() {
         
        return (List<Product>) productRepository.findAll();
 
    }
}
