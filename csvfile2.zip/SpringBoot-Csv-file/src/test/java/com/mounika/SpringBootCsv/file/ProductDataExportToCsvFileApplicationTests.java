package com.mounika.SpringBootCsv.file;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductDataExportToCsvFileApplicationTests {

	@Test
	void contextLoads() {
	}

}
